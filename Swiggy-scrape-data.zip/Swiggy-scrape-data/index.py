import requests
import json
import pandas as pd

# Swiggy API URL
url = "https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=12.956924&lng=77.701127&restaurantId=879217&catalog_qa=undefined&submitAction=ENTER"

# Set headers to mimic a browser request (optional, avoids blocking)
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
}

# Send a GET request
response = requests.get(url, headers=headers)

# Parse the JSON response
data = response.json()



menu_cards = data["data"]["cards"]

fin_cards = []
for card in menu_cards:
    if "groupedCard" in card:
        cards = card.get("groupedCard", {}).get("cardGroupMap", {}).get("REGULAR", {}).get("cards", [])
        fin_cards.extend(cards)
item_categories = [
    card["card"]["card"] for card in fin_cards
    if card.get("card", {}).get("card", {}).get("@type") == "type.googleapis.com/swiggy.presentation.food.v2.ItemCategory"
]



# List to store structured data
data_rows = []

for category in item_categories:
    category_name = category.get("title", "Unknown Category")
    
    # Check if itemCards exist
    item_cards = category.get("itemCards", [])
    
    first_item = True  # Flag to track first item in the category

    for item in item_cards:
        item_info = item.get("card", {}).get("info", {})
        item_name = item_info.get("name", "Unknown Item")
        price = item_info.get("price", 0) / 100  # Convert price from paise to INR
        fin_price = item_info.get("finalPrice", 0) / 100

        final_price = "NA" if fin_price == 0 else fin_price # Convert price from paise to INR
        
        # Check if item has addons
        addons = item_info.get("addons", [])

        # Set category name only for the first item, then leave blank
        if first_item:
            data_rows.append([category_name, item_name, price, final_price, "", ""])
            first_item = False  # Reset flag after first item
        else:
            data_rows.append(["", item_name, price, final_price, "", ""])

        # Add add-ons
        for addon in addons:
            for choice in addon.get("choices", []):
                addon_name = choice.get("name", "Unknown Addon")
                addon_price = choice.get("price", 0) / 100  # Convert price from paise to INR
                data_rows.append(["", "", "", "", addon_name, addon_price])  # Add-on row

# Define column names
columns = ["Category", "Item", "Price", "Final Price", "Add-on", "Add-on Price"]

# Create a DataFrame
df = pd.DataFrame(data_rows, columns=columns)

# Save to Excel file

excel_name = str(menu_cards[0]["card"]["card"]["text"])+"_menu.xlsx"
df.to_excel(excel_name, index=False)
